abstract public class RunnerID {
    // Do Not change this class
    public abstract boolean isSmaller(RunnerID other);
    public abstract String toString();
}
